Warehouse with dimesion in mm and planimetry image
Stock location with position and size coordinates
Stored link between warehouse and location
Location tags to color locations in 3d View
