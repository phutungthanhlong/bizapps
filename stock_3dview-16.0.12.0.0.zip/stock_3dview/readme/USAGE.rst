To use this module, you need to:

#. Go to 'Inventory / Settings / Locations'
#. from listview select new icon for 3d view
