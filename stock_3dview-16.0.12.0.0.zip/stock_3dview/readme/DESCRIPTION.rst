Stock location 3D view
